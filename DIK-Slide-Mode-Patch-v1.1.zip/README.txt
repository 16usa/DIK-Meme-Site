DIK Slide Mode Patch v1.1

Run from the existing ~/workspace repo root.
This installer only replaces:
- artifacts/dik-meme-site/site/index.html
- artifacts/dik-meme-site/site/styles.css
- artifacts/dik-meme-site/site/script.js

It does NOT restart or kill the server, does NOT run npm/pnpm, and does NOT modify .replit, server.js, config.js, or workspace setup.
