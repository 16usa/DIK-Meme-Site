#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(pwd)"
TARGET="$ROOT/artifacts/dik-meme-site/site"

if [ ! -d "$TARGET" ]; then
  echo "ERROR: Run this from the existing DIK-Meme-Site workspace root."
  exit 1
fi

cp "$PATCH_DIR/files/index.html" "$TARGET/index.html"
cp "$PATCH_DIR/files/styles.css" "$TARGET/styles.css"
cp "$PATCH_DIR/files/script.js" "$TARGET/script.js"

echo "DIK Slide Mode v1.1 installed."
echo "No restart. No process kill. No npm install."
